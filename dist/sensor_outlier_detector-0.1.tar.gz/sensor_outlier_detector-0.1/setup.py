from setuptools import setup

setup(name='sensor_outlier_detector',
      version='0.1',
      description='sensor data outlier in the world',
      url='http://github.com/vijayendra-g/sensor_outlier_detector',
      author='vijay G',
      author_email='vijayendra.iiith@gmail.com',
      license='GNU',
      packages=['sensor_outlier_detector'],
      zip_safe=False)